//
//  websiteviewcontroller.swift
//  MAVRICK
//
//  Created by APPLE on 08/02/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit
import WebKit

class websiteviewcontroller: UIViewController, WKUIDelegate,WKNavigation{
    
    var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        webViedq()
        // do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        //Dispose of any resources that can be recreated.
    }
    func webViedq()
    {UIApplication.shared.open(URL(string: "httpp://www.cliqueav-india.com/")! as URL, options: [:], completionHandler: nil)
        
    }
    
    override func loadView() {
        webView = WKWebView()
        webView.navigationDelegate = self as? WKNavigationDelegate
        view = webView
    }
}

