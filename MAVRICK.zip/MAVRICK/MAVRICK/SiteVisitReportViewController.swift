//
//  SiteVisitReportViewController.swift
//  MAVRICK
//
//  Created by APPLE on 21/12/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit



class SiteVisitReportViewController: UIViewController {
    @IBOutlet weak var SiteName: UITextField!
    @IBOutlet weak var SiteVisit: UITextField!
    @IBOutlet weak var sitedate: UIDatePicker!
    @IBOutlet weak var ContactNo: UITextField!
    @IBOutlet weak var PersonalMeet: UITextField!
    
    
    
    
    @IBOutlet weak var Checkbox1: CheckBox!
    @IBOutlet weak var Checkbox2: CheckBox!
    @IBOutlet weak var Checkbox3: CheckBox!
    @IBOutlet weak var Checkbox4: CheckBox!
    @IBOutlet weak var Checkbox5: CheckBox!
    @IBOutlet weak var Checkbox6: CheckBox!
    @IBOutlet weak var Checkbox7: CheckBox!
    @IBOutlet weak var Checkbox8: CheckBox!
    
    
    @IBOutlet weak var Checkbox9: CheckBox!
    @IBOutlet weak var Checkbox10: CheckBox!
    @IBOutlet weak var Checkbox11: CheckBox!
    @IBOutlet weak var Checkbox12: CheckBox!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        Checkbox1.setImage(UIImage(named: "unchecked-checkbox"),for:.normal)
        Checkbox1.setImage(UIImage(named: "unchecked-checkbox"),for:.selected)
        
        Checkbox2.setImage(UIImage(named: "unchecked-checkbox"),for:.normal)
        Checkbox2.setImage(UIImage(named:"unchecked-checkbox"),for:.selected)
        
        Checkbox3.setImage(UIImage(named:"unchecked-checkbox"),for:.normal)
        Checkbox3.setImage(UIImage(named:"unchecked-checkbox"),for:.selected)
        
        Checkbox4.setImage(UIImage(named:"Unchecked-checkbox"),for:.normal)
        Checkbox4.setImage(UIImage(named:"Unchecked-checkbox"),for:.selected)
        
        Checkbox5.setImage(UIImage(named:"unchecked-checkbox"),for:.normal)
        Checkbox5.setImage(UIImage(named:"Unchecked_checkbox"),for:.selected)
        
        
        Checkbox6.setImage(UIImage(named:"unchecked-checkbox"),for:.normal)
        Checkbox6.setImage(UIImage(named:"unchecked-checkbox"),for:.selected)
        
        Checkbox7.setImage(UIImage(named:"unchecked-checkbox"),for:.normal)
        Checkbox7.setImage(UIImage(named:"unchecked-checkbox"),for:.selected)
        
        Checkbox8.setImage(UIImage(named:"unchecked-checkbox"),for:.normal)
        Checkbox8.setImage(UIImage(named:"unchecked-checkbox"),for:.selected)
        
        Checkbox9.setImage(UIImage(named:"unchecked-checkbox"),for:.normal)
        Checkbox9.setImage(UIImage(named:"unchecked-checkbox"),for:.selected)
        
        Checkbox10.setImage(UIImage(named:"unchecked-checkbox"),for:.normal)
        Checkbox10.setImage(UIImage(named:"unchecked-checkbox"),for:.selected)
        
        Checkbox11.setImage(UIImage(named:"unchecked-checkbox"),for:.normal)
        Checkbox11.setImage(UIImage(named:"unchecked-checkbox"),for:.selected)
        
        Checkbox12.setImage(UIImage(named:"unchecked-checkbox"),for:.normal)
        Checkbox12.setImage(UIImage(named:"unchecked-checkox"),for:.selected)

        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func submit(_ sender: UIButton) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
