//
//  sitevisitViewController.swift
//  
//
//  Created by APPLE on 05/02/19.
//





   

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase
import ProgressHUD

class SiteVisitViewController: UIViewController {
    //var inputsOutputs = [[String:AnyObject]]()
  
    @IBOutlet weak var SiteName: UITextField!
    @IBOutlet weak var VisitedBy: UITextField!
    @IBOutlet weak var SiteDate: UIDatePicker!
    @IBOutlet weak var Contact: UITextField!
    @IBOutlet weak var personalmeet: UITextField!
    
   

    
    
    
    
    
    @IBOutlet weak var checkbox1: CheckBox!
    @IBOutlet weak var checkbox2: CheckBox!
    @IBOutlet weak var checkbox3: CheckBox!
    @IBOutlet weak var checkbox4: CheckBox!
    @IBOutlet weak var checkbox5: CheckBox!
    @IBOutlet weak var checkbox6: CheckBox!
    @IBOutlet weak var checkbox7: CheckBox!
    @IBOutlet weak var checkbox8: CheckBox!
    @IBOutlet weak var checkbox9: CheckBox!
    @IBOutlet weak var checkbox10: CheckBox!
    @IBOutlet weak var checkbox11: CheckBox!
    @IBOutlet weak var checkbox12: checkbox!
    
    
    
    var ref: DatabaseReference!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       ref = Database.database().reference()
        
        checkbox1.setImage(UIImage(named: "unchecked_checkbox"),for: .normal)
        checkbox1.setImage(UIImage(named: "checked_checkbox"),for: .selected)
        
        checkbox2.setImage(UIImage(named: "unchecked_checkbox"),for: .normal)
        checkbox2.setImage(UIImage(named:"checked_checkbox"),for: .selected)
        
        checkbox3.setImage(UIImage(named:"unchecked_checkbox"),for: .normal)
        checkbox3.setImage(UIImage(named:"checked_checkbox"),for: .selected)
        
        checkbox4.setImage(UIImage(named:"Unchecked_checkbox"),for: .normal)
        checkbox4.setImage(UIImage(named:"checked_checkbox"),for: .selected)
        
        checkbox5.setImage(UIImage(named:"unchecked_checkbox"),for: .normal)
        checkbox5.setImage(UIImage(named:"checked_checkbox"),for: .selected)
        
        
        checkbox6.setImage(UIImage(named:"unchecked_checkbox"),for: .normal)
        checkbox6.setImage(UIImage(named:"checked_checkbox"),for: .selected)
        
        checkbox7.setImage(UIImage(named:"unchecked_checkbox"),for: .normal)
        checkbox7.setImage(UIImage(named:"checked_checkbox"),for: .selected)
        
        checkbox8.setImage(UIImage(named:"unchecked_checkbox"),for: .normal)
        checkbox8.setImage(UIImage(named:"checked_checkbox"),for: .selected)
        
        checkbox9.setImage(UIImage(named:"uncheckedc_heckbox"),for:.normal)
        checkbox9.setImage(UIImage(named:"checked_checkbox"),for:.selected)
        
        checkbox10.setImage(UIImage(named:"unchecked_checkbox"),for:.normal)
        checkbox10.setImage(UIImage(named:"checked_checkbox"),for:.selected)
        
        checkbox11.setImage(UIImage(named:"unchecked_checkbox"),for:.normal)
        checkbox11.setImage(UIImage(named:"checked_checkbox"),for:.selected)
        
        checkbox12.setImage(UIImage(named:"unchecked_checkbox"),for:.normal)
        checkbox12.setImage(UIImage(named:"checked_checkox"),for:.selected)
        
        
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
 
    @IBAction func checkbox1(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {sender.transform = CGAffineTransform(scaleX: 0.1, y: 0.1 )})
        {
            (success) in UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {
                sender.isSelected = !sender.isSelected
                sender.transform = .identity
            }, completion: nil)
        }
    }
    
    @IBAction func checkbox2(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {sender.transform = CGAffineTransform(scaleX: 0.1, y: 0.1 )})
        {
            (success) in UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {
                sender.isSelected = !sender.isSelected
                sender.transform = .identity
            }, completion: nil)
        }
    }
    
    @IBAction func checkbox3(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {sender.transform = CGAffineTransform(scaleX: 0.1, y: 0.1 )})
        {
            (success) in UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {
                sender.isSelected = !sender.isSelected
                sender.transform = .identity
            }, completion: nil)
        }
    }
    @IBAction func checkbox4(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {sender.transform = CGAffineTransform(scaleX: 0.1, y: 0.1 )})
        {
            (success) in UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {
                sender.isSelected = !sender.isSelected
                sender.transform = .identity
            }, completion: nil)
        }
    }
    
    @IBAction func checkbox5(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {sender.transform = CGAffineTransform(scaleX: 0.1, y: 0.1 )})
        {
            (success) in UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {
                sender.isSelected = !sender.isSelected
                sender.transform = .identity
            }, completion: nil)
        }
    }
    
    @IBAction func checkbox6(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {sender.transform = CGAffineTransform(scaleX: 0.1, y: 0.1 )})
        {
            (success) in UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {
                sender.isSelected = !sender.isSelected
                sender.transform = .identity
            }, completion: nil)
        }
    }
    
    @IBAction func checkbox7(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {sender.transform = CGAffineTransform(scaleX: 0.1, y: 0.1 )})
        {
            (success) in UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {
                sender.isSelected = !sender.isSelected
                sender.transform = .identity
            }, completion: nil)
        }
    }
    
    @IBAction func checkbox8(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {sender.transform = CGAffineTransform(scaleX: 0.1, y: 0.1 )})
        {
            (success) in UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {
                sender.isSelected = !sender.isSelected
                sender.transform = .identity
            }, completion: nil)
        }
    }
    
    @IBAction func checkbox9(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {sender.transform = CGAffineTransform(scaleX: 0.1, y: 0.1 )})
        {
            (success) in UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {
                sender.isSelected = !sender.isSelected
                sender.transform = .identity
            }, completion: nil)
        }
    }
    
    @IBAction func checkbox10(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {sender.transform = CGAffineTransform(scaleX: 0.1, y: 0.1 )})
        {
            (success) in UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {
                sender.isSelected = !sender.isSelected
                sender.transform = .identity
            }, completion: nil)
        }
    }
    
    @IBAction func checkbox11(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {sender.transform = CGAffineTransform(scaleX: 0.1, y: 0.1 )})
        {
            (success) in UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {
                sender.isSelected = !sender.isSelected
                sender.transform = .identity
            }, completion: nil)
        }
    }
    
    @IBAction func checkbox12(_ sender: UIButton) {
        UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {sender.transform = CGAffineTransform(scaleX: 0.1, y: 0.1 )})
        {
            (success) in UIView.animate(withDuration: 0.5,delay: 0.1, options: .curveLinear, animations: {
                sender.isSelected = !sender.isSelected
                sender.transform = .identity
            }, completion: nil)
        }
    }
    
    @IBAction func submit(_ sender: UIButton) {
        
        //Calling Fuction
        self.myalert("Success", "Your data has been saved")
        let sub = self.storyboard?.instantiateViewController(withIdentifier:"SiteVisitViewController")as? SiteVisitViewController
        self.navigationController?.pushViewController(sub!, animated: true)
    }
    
    
    
    //custom function
    func myalert(_ mytitle:String, _ mymessage:String)
    {
        let alert = UIAlertController(title: mytitle, message: mymessage, preferredStyle: .actionSheet)
        let ok = UIAlertAction(title: "Done", style: .default, handler: nil)
        alert.addAction(ok)
        self.present(alert,animated: true,completion: nil)
    }
    

    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
