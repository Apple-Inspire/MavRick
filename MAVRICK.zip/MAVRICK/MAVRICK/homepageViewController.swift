//
//  homepageViewController.swift
//  MAVRICK
//
//  Created by APPLE on 21/12/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class homepageViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var menutable: UITableView!
    @IBOutlet weak var logo: UIImageView!
  
    let listArray = ["OUR SERVICES","REQUEST A QUOTE","SITE VISIT","SKILL SET FORM","CONTACT US","TERMS & CONDITION","WEBSITE"]
    var tableView: UITableView!
    var myIndex = 0
    
  
    


    override func viewDidLoad() {
        super.viewDidLoad()
        menutable.dataSource = self as UITableViewDataSource
        menutable.delegate = self as UITableViewDelegate
        menutable.isHidden = true
        logo.isHidden = true
        
        // Do any additional setup after loading the view.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
   public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return listArray.count
    }
  
    

  
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        myIndex = indexPath.row
        if (myIndex == 0){
            let oneView=self.storyboard?.instantiateViewController(withIdentifier: "ourservicesViewController") as? ourservicesViewController
            self.navigationController?.pushViewController(oneView!, animated: true)
        }
        if (myIndex == 1){
            let twoView=self.storyboard?.instantiateViewController(withIdentifier: "QuoteViewController") as? QuoteViewController
            self.navigationController?.pushViewController(twoView!, animated: true)
        }
        if (myIndex == 2){
            let threeView=self.storyboard?.instantiateViewController(withIdentifier: "SiteVisitViewController") as?SiteVisitViewController
            self.navigationController?.pushViewController(threeView!, animated: true)
        }
        
        if (myIndex == 3){
            let fourView=self.storyboard?.instantiateViewController(withIdentifier: "SkillSetForm") as?SkillSetForm
            self.navigationController?.pushViewController(fourView!, animated: true)
        }
        if (myIndex == 4){
            let fiveView=self.storyboard?.instantiateViewController(withIdentifier:"contactPageViewController") as? ContactViewController
            self.navigationController?.pushViewController(fiveView!, animated: true)
        }
        if (myIndex == 5){
            let sixView=self.storyboard?.instantiateViewController(withIdentifier:"TermsViewController") as? TermsViewController
            self.navigationController?.pushViewController(sixView!, animated: true)
        }
    
    if (myIndex == 6){
    let regView = self.storyboard?.instantiateViewController(withIdentifier:"WebSiteViewController") as? WebSiteViewController
    self.navigationController?.pushViewController(regView!, animated: true)
    }
    }
    
   public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "cell")
        
        cell.textLabel?.text = listArray [indexPath.row]
        return(cell)
        
    }
    
  
    @IBAction func menubar(_ sender: UIBarButtonItem) {
        
            if menutable.isHidden == true {
                menutable.isHidden = false
            }
            else{
                menutable.isHidden = true
            }
        if logo.isHidden == true{
            logo.isHidden = false
        }
        else {
            logo.isHidden = true
        }
        }
    }
    



