//
//  checkbox.swift
//  MAVRICK
//
//  Created by APPLE on 21/12/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class CheckBox: UIButton {
    
    //images
    let checkedImage = UIImage(named: "checked_checkbox")
    let uncheckedImage = UIImage(named: "unchecked_checkbox")
    
    // bool propetry
    var isChecked:Bool = false{
        didSet{
            if isChecked == true{
                self.setImage(checkedImage, for: .normal)
                }else{
                self.setImage(uncheckedImage, for: .normal)
                
            }
        }
    }
    override func awakeFromNib() {
        self.addTarget(self, action: Selector(("buttonClicked")), for: UIControlEvents.touchUpInside)
            self.isChecked = false
        
    }
    func buttonClicked(sender:UIButton){
        if (sender==self){
            if isChecked == true{
                isChecked = false
            }else{
                isChecked=true
            }
        }
    }
}

class checkbox: UIButton {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
