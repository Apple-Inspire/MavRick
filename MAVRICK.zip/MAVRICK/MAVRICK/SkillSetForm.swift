//
//  SkillSetForm.swift
//  MAVRICK
//
//  Created by APPLE on 15/01/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class SkillSetForm: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var SelectSkill: UITableView!
    
    @IBOutlet weak var rack: CheckBox!
    @IBOutlet weak var video: CheckBox!
    @IBOutlet weak var videowall: CheckBox!
    @IBOutlet weak var audio: CheckBox!
    @IBOutlet weak var toursound: CheckBox!
    @IBOutlet weak var auditorium: CheckBox!
    @IBOutlet weak var studio: CheckBox!
    @IBOutlet weak var cinema: CheckBox!
   
    let listArray = ["Installation","Fabrication","Programing","AV Designing","Interior Draughtman","Electrician","Maintenance","Routing(Cabling)","Trouble Shooting","Project Management","Documentation"]
    var myIndex = 0
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt IndexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style:UITableViewCellStyle.default, reuseIdentifier:"cell")
        cell.textLabel?.text = listArray [IndexPath.row]
        return (cell)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        rack.setImage(UIImage(named: "unchecked_checkbox"), for: .normal)
        rack.setImage(UIImage(named: "checked_checkbox"), for: .selected)
        video.setImage(UIImage(named: "unchecked_checkbox"), for: .normal)
        video.setImage(UIImage(named: "checked_checkbox"), for: .selected)
        videowall.setImage(UIImage(named: "unchecked_checkbox"), for: .normal)
        videowall.setImage(UIImage(named: "checked_checkbox"), for: .selected)
        audio.setImage(UIImage(named: "unchecked_checkbox"), for: .normal)
        audio.setImage(UIImage(named: "cheked_checkbox"), for: .selected)
        toursound.setImage(UIImage(named: "unchecked_checkbox"), for: .normal)
        toursound.setImage(UIImage(named: "checked_checkbox"), for: .selected)
        auditorium.setImage(UIImage(named: "unchecked_checkbox"), for: .normal)
        auditorium.setImage(UIImage(named: "checked_checkbox"), for: .selected)
        studio.setImage(UIImage(named: "unchecked_checkbox"), for: .normal)
        studio.setImage(UIImage(named: "checked_checkbox"), for: .selected)
        cinema.setImage(UIImage(named: "unchecked_checkbox"), for: .normal)
        cinema.setImage(UIImage(named: "checked_checkbox"), for: .selected)
        
        
        SelectSkill.dataSource = self
        SelectSkill.delegate = self
        SelectSkill.isHidden = true
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func rack(_ sender: UIButton) {
    
        if sender.isSelected {
            sender.isSelected = false
        }else{
            sender.isSelected = true
        }
       
    }
    
    @IBAction func video(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
        }else{
            sender.isSelected = true
        }
      
    }
    
    @IBAction func videowall(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
        }else{
            sender.isSelected = true
        }
    }
    
    
    @IBAction func audio(_ sender: UIButton) {
        
        if sender.isSelected {
            sender.isSelected = false
        }else{
            sender.isSelected = true
        }
    }
    
    
    @IBAction func toursound(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
        }else{
            sender.isSelected = true
        }
    }
    
    @IBAction func auditorium(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
        }else{
            sender.isSelected = true
        }
    }
    
    
    @IBAction func studio(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
        }else{
            sender.isSelected = true
        }
    }
    
    @IBAction func cinema(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
        }else{
            sender.isSelected = true
        }
    }
    
    
    @IBAction func down(_ sender: UIButton) {
        
            
            if SelectSkill.isHidden == true {
                SelectSkill.isHidden = false
            }
            else{
                SelectSkill.isHidden = true
            }
        
        
    }
    
}


func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
}
    


